/* Figure 8.11  Exchanging String Elements of an Array */
strcpy(temp, list[index_of_min]);
strcpy(list[index_of_min], list[fill]);
strcpy(list[fill], temp);
