/* Figure 3.34  Program to Paint a House */
/* Paints a house */
#include <graphics.h>

int
main(void)
{
   /* Define corners of house */
   int x1 = 100; int y1 = 200;         /* top-left corner */
   int x2 = 300; int y2 = 100;         /* roof peak */
   int x3 = 500; int y3 = 200;         /* top-right corner */
   int x4 = 500; int y4 = 400;         /* bottom-right corner */
   int x5 = 325; int y5 = 400;  /* bottom-right corner of door */
   int x6 = 275; int y6 = 325;      /* top-left corner of door */

   initwindow(640, 500,
              "Painted house - press a key to close", 100, 50);
   /* Draw roof */
   line(x1, y1, x2, y2);
   line(x2, y2, x3, y3);

   /* Draw rest of house */
   rectangle(x1, y1, x4, y4);

   /* Paint the house */
   setfillstyle(HATCH_FILL, LIGHTGRAY);
   floodfill(x2, y2 + 10, WHITE);       /* Paint the roof */
   setfillstyle(LINE_FILL, WHITE);
   floodfill(x2, y1 + 10, WHITE);       /* Paint the house */

   setfillstyle(SOLID_FILL, BLUE);
   bar(x5, y5, x6, y6);             /* Draw blue door */

   getch();
   closegraph();

   return(0);
}
