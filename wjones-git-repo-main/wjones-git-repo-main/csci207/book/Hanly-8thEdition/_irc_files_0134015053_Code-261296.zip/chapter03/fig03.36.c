/* Figure 3.36  Program to Draw a Pirate */
/* Draws a pirate */
#include <graphics.h>

int
main(void)
{
   int midX, midY;            /* coordinates of center point */
   int leftEyeX, rightEyeX, eyeY;    /* eye center points */
   int noseX, noseY;                 /* nose center point */
   int headRadius;                   /* head radius */
   int eyeNoseRadius;                /* eye/nose radius */
   int smileRadius;                  /* smile radius */
   int stepX, stepY;                 /* x and y increments */

   initwindow(500, 400,
              "Pirate - press key to close", 200, 150);

   /* Draw head. */
   midX = getmaxx() / 2;          /* center head in x-direction. */
   midY = getmaxy() / 2;          /* center head in y-direction. */
   headRadius = getmaxy() / 4;
   circle (midX, midY, headRadius);  /* draw head. */

   /* Draw eyes. */
   stepX = headRadius / 4;         /* x-offset for eyes */
   stepY = stepX;                  /* y-offset for eyes and nose */
   leftEyeX = midX - stepX;        /* x-coordinate for left eye */
   rightEyeX = midX + stepX;       /* x-coordinate for right eye */
   eyeY = midY - stepY;            /* y-coordinate for both eyes */
   eyeNoseRadius = headRadius / 10;
   circle(leftEyeX, eyeY, eyeNoseRadius);    /* draw left eye. */
   circle(rightEyeX, eyeY, eyeNoseRadius);   /* draw right eye. */

   /* Draw nose. */
   noseX = midX;               /* nose is centered in x direction. */
   noseY = midY + stepY;
   circle(noseX, noseY, eyeNoseRadius);

   /* Draw smile -- use 3/4 of head radius. */
   smileRadius = (int)(0.75 * headRadius + 0.5);
   /* Draw frown */
   arc(midX, midY + headRadius, 65, 115, smileRadius / 2);

   setfillstyle(CLOSE_DOT_FILL, WHITE);
   pieslice(midX, midY, 10, 60, smileRadius); /* Draw eye patch */

   outtextxy(getmaxx() / 3, getmaxy() - 20,
             "PIRATE WITH AN EYE PATCH");

   getch();
   closegraph();

return(0);
}
