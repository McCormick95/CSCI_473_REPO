/* Figure 3.16  Function instruct and the Output Produced by a Call */
/*
 * Displays instructions to a user of program to compute
 * the area and circumference of a circle.
 */
void
instruct(void)
{
      printf("This program computes the area\n");
      printf("and circumference of a circle.\n\n");
      printf("To use this program, enter the radius of\n");
      printf("the circle after the prompt: Enter radius>\n");
}

/*
This program computes the area
and circumference of a circle.
To use this program, enter the radius of
the circle after the prompt: Enter radius>
*/
