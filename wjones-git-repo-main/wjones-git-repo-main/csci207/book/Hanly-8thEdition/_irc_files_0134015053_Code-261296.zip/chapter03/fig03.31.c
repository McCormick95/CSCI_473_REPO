/* Figure 3.31  Program to Draw a Happy Face */
/* Draws a happy face */

#include <graphics.h>

int
main(void)
{
   int midX, midY,                     /* coordinates of center point */
       leftEyeX, rightEyeX, eyeY,      /* eye center points */
       noseX, noseY,                   /* nose center point */
       headRadius,                     /* head radius */
       eyeNoseRadius,                  /* eye/nose radius */
       smileRadius,                    /* smile radius */
       stepX, stepY;                   /* x and y increments */

   initwindow(500, 400,
              "Happy Face - press key to close", 200, 150);

   /* draw head */
   midX = getmaxx() / 2;            /* center head in x-direction */
   midY = getmaxy() / 2;            /* center head in y-direction */
   headRadius = getmaxy() / 4;  /* head will fill half the window */
   circle(midX, midY, headRadius); /* draw head */

   /* draw eyes */
   stepX = headRadius / 4;         /* x-offset for eyes */
   stepY = stepX;                  /* y-offset for eyes and nose */
   leftEyeX = midX - stepX;        /* x-coordinate for right eye */
   eyeY = midY - stepY;            /* y-coordinate for both eyes */
   eyeNoseRadius = headRadius / 10;
   circle(leftEyeX, eyeY, eyeNoseRadius);    /* draw left eye. */
   circle(rightEyeX, eyeY, eyeNoseRadius);   /* draw right eye. */

   /* draw nose */
   noseX = midX;           /* nose is centered in x direction. */
   noseY = midY + stepY;
   circle(noseX, noseY, eyeNoseRadius);

   /* draw smile */
   smileRadius = (int)(0.75 * headRadius + 0.5);
   arc(midX, midY, 210, 330, smileRadius);

   getch();
   closegraph();

   return(0);
}
