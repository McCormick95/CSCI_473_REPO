/* FIGURE 12.3  Portion of Program That Uses Functions from a Personal Library */
/*
 * Beginning of source file in which a personal library and system I/O library
 * are used.
 */

#include <stdio.h>     /* system's standard I/O functions                     */

#include "planet.h"    /* personal library with planet_t data type and
                            operators                                         */
. . .
