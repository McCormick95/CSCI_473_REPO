/* FIGURE 4.13  Program Using a switch Statement for Selection */
/*
 * Reads serial number and displays class of ship
 */

#include <stdio.h>

int
main(void)
{
    char class;     /* input - character indicating class of ship */

    /* Read first character of serial number */
    printf("Enter ship serial number> ");
    scanf("%c", &class);         /* scan first letter */

    /* Display first character followed by ship class */
    printf("Ship class is %c: ", class);
    switch (class) {
    case 'B':
    case 'b':
            printf("Battleship\n");
            break;
    case 'C':
    case 'c':
            printf("Cruiser\n");
            break;
    case 'D':
    case 'd':
            printf("Destroyer\n");
            break;
    case 'F':
    case 'f':
            printf("Frigate\n");
            break;
    default:
            printf("Unknown\n");
    }

    return (0);
}

/*
Sample Run 1
Enter ship serial number> f3456
Ship class is f: Frigate

Sample Run 2
Enter ship serial number> P210
Ship class is P: Unknown
*/
