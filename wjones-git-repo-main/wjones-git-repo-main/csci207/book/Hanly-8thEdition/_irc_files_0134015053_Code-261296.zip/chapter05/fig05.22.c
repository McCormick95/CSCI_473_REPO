/* FIGURE 5.22  Program to Draw a Quilt */
/*
 * Display a pattern for a quilt -- a set of nested rectangles
 */
#include <graphics.h>
#include <stdio.h>

int
main(void)
{
   int x1, y1, x2, y2;     /* coordinates of corner points */
   int stepX, stepY;       /* change in coordinate values */
   int foreColor;          /* foreground color */
   int numBars;            /* number of bars */
   int width, height;      /* screen width and height */

   printf(�Enter number of bars> �);
   scanf(�%d�, &numBars);

   width = getmaxwidth();
   height = getmaxheight();

   initwindow(width, height, �Quilt�);

   /* set corner points of outermost bar
      and increments for inner bars */
   x1 = 0;           y1 = 0;            /* top left corner */
   x2 = width;       y2 = height;       /* bottom right corner */
   stepX = width / (2 * numBars);       /* x increment */
   stepY = height / (2 * numBars);      /* y increment */

   for (int i = 1; i <= numBars; ++i)
   {
      foreColor = i % 16;               /* 0 <= foreColor <= 15 */
      setcolor(foreColor);
      setfillstyle(i % 12, foreColor);  /* Set fill style */
      bar(x1, y1, x2, y2);              /* Draw a bar */
      x1 = x1 + stepX; y1 = y1 + stepY; /* Change top left corner */
      x2 = x2 - stepX; y2 = y2 - stepY; /* Change bottom right */
   }

   getch();       /* pause for user */
   closegraph();
   return (0);
}

