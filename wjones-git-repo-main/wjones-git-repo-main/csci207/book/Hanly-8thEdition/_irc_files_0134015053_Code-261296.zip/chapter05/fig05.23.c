/* FIGURE 5.23  Program to Draw a Moving Ball */
/*
 * Draw a ball that moves around the screen
 */
#include <graphics.h>
#define TRUE 1

int
main(void)
{
    const int PAUSE = 20;      /* delay between frames */
    const int DELTA = 5;       /* change in x or y value */
    const int RADIUS = 30;     /* ball radius */
    const int COLOR = RED;

    int width;                 /* width of screen */
    int height;                /* height of screen */
    int x; int y;              /* center of ball */
    int stepX;                 /* increment for x */
    int stepY;                 /* increment for y */

    /* Open a full-screen window with double buffering */
     width = getmaxwidth();
     height = getmaxheight();
     initwindow(width, height,
                �Pong - close window to quit�, 0, 0, TRUE);
     x = RADIUS; y = RADIUS;        /* Start ball at top-left corner */
     stepX = DELTA;  stepY = DELTA; /* Move down and to the right */

     /* Draw the moving ball */
     while (TRUE)    /* Repeat forever */
     {
         /* Clear the old frame and draw the new one. */
         clearviewport();
         setfillstyle(SOLID_FILL, COLOR);
         fillellipse(x, y, RADIUS, RADIUS);  /* Draw the ball */

         /* After drawing the frame, swap the buffers */
         swapbuffers();
         delay(PAUSE);

         /* If ball is too close to window edge, change direction           */
         if (x <= RADIUS)               /* Is ball too close to left edge?  */
            stepX = DELTA;              /* Move right                       */
         else if (x >= width - RADIUS)  /* Is ball too close to right edge? */
            stepX = -DELTA;             /* Move left                        */

         if (y <= RADIUS)               /* Is ball too close to top?        */
            stepY = DELTA;              /* Move down                        */
         else if (y >= height - RADIUS) /* Is ball too close to bottom?     */
            stepY = -DELTA;             /* Move up                          */


       /* Move the ball */
       x = x + stepX;
       y = y + stepY;
     }

     closegraph();
     return (0);
}

