/* FIGURE 5.8  Displaying a Celsius-to-Fahrenheit Conversion Table */
/* Conversion of Celsius to Fahrenheit temperatures */

#include <stdio.h>

/* Constant macros */
#define CBEGIN 10
#define CLIMIT -5
#define CSTEP 5

int
main(void)
{
       /* Variable declarations */
       int    celsius;
       double fahrenheit;

       /* Display the table heading */
       printf(" Celsius Fahrenheit\n");

       /* Display the table */
 1     for  (celsius = CBEGIN;
 2           celsius >= CLIMIT;
 3           celsius -= CSTEP) {
 4           fahrenheit = 1.8 * celsius + 32.0;
 5           printf("%6c%3d%8c%7.2f\n", ' ', celsius, ' ', fahrenheit);
       }

       return (0);
}

/*
   Celsius     Fahrenheit
       10           50.00
        5           41.00
        0           32.00
       -5           23.00
*/
