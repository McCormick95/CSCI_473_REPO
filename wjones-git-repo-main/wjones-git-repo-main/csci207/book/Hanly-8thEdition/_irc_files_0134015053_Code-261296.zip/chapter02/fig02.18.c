/* FIGURE 2.18  Revised Start of main Function for Supermarket Coin Value Program */
int
main(void)
{
     char first, middle, last; /* input - 3 initials            */
     int pennies, nickels;   /* input - count of each coin type */
     int dimes, quarters;    /* input - count of each coin type */
     int dollars;            /* input - count of each coin type */
     int change;                /* output - change amount       */
     int total_dollars;         /* output - dollar amount       */
     int total_cents;           /* total cents                  */
     int year;                  /* input � year                 */

     /* Get the current year.                                   */
     printf("Enter the current year and press return> ");
     scanf("%d", &year);

     /* Get and display the customer's initials.                */
     printf("Type in 3 initials and press return> ");
     scanf("%c%c%c", &first, &middle, &last);
     printf("\n%c%c%c, please enter your coin information for %d.\n",
            first, middle, last, year);
...
