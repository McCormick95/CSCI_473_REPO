/* Figure 7.25  Function scan_table and Helper Function Initialize */
/*
 * Scans the revenue data from REVENUE_FILE and computes and stores the
 * revenue results in the revenue table. Flags out-of-range data and data
 * format errors.
 * Post:  Each entry of revenue represents the revenue total for a
 *        particular unit and quarter.
 *        Returns 1 for successful table scan, 0 for error in scan.
 * Calls: initialize to initialize table to all zeros
 */
int
scan_table(double revenue[][NUM_QUARTERS], /* output */
           int num_rows)                   /* input  */
{
      double   trans_amt;      /* transaction amount */
      int      trans_unit;     /* unit number        */
      int      quarter;        /* revenue quarter    */
      FILE    *revenue_filep;  /* file pointer to revenue file */
      int      valid_table = 1;/* data valid so far */
      int      status;         /* input status       */
      char     ch;             /* one character in bad line */

      /* Initialize table to all zeros */
      initialize(revenue, num_rows, 0.0);

      /* Scan and store the valid revenue data */
      revenue_filep = fopen(REVENUE_FILE, "r");
      for  (status = fscanf(revenue_filep, "%d%d%lf", &trans_unit,
                            &quarter, &trans_amt);
            status == 3 && valid_table;
            status = fscanf(revenue_filep, "%d%d%lf", &trans_unit,
                      &quarter, &trans_amt)) {
        if (summer <= quarter && quarter <= spring &&
            trans_unit >= 0 && trans_unit < num_rows) {
              revenue[trans_unit][quarter] += trans_amt;
        } else {
              printf("Invalid unit or quarter -- \n");
              printf(" unit is ");
              display_unit(trans_unit);
              printf(", quarter is ");
              display_quarter(quarter);
              printf("\n\n");
              valid_table = 0;
        }
      }

      if (!valid_table) {         /* error already processed */
            status = 0;
      } else if (status == EOF) { /* end of data without error */
            status = 1;
      } else {                    /* data format error */
            printf("Error in revenue data format. Revise data.\n");
            printf("ERROR HERE >>> ");
            for  (status = fscanf(revenue_filep, "%c", &ch);
                  status == 1 && ch != '\n';
                  status = fscanf(revenue_filep, "%c", &ch))
                printf("%c", ch);
            printf(" <<<\n");
            status = 0;
       }
       return (status);
}
/*
 * Stores value in all elements of revenue.
 * Pre: value is defined and num_rows is the number of rows in
 *      revenue.
 * Post: All elements of revenue have the desired value.
 */
void
initialize(double revenue[][NUM_QUARTERS], /* output */
           int    num_rows,                /* input  */
           double value)                   /* input  */
{
      int       row;
      quarter_t quarter;

      for (row = 0; row < num_rows; ++row)
         for (quarter = summer; quarter <= spring; ++quarter)
            revenue[row][quarter] = value;
}
