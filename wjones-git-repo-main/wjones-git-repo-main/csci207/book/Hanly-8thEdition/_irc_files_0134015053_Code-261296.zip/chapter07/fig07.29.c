/* Figure 7.29  Program to Draw a Two-Dimensional Grid */
/* Draws a grid and displays the row, column
 * of a selected cell
 */
#include <graphics.h>
#include <stdio.h>

#define NUM_ROWS 5
#define NUM_COLS 6
#define CELL_SIZE 50 /* dimensions of a square cell */

void drawGrid(int gridArray[][NUM_COLS]);
void reportResult(int *row, int *column, int *color);
void recolor(int r, int c, int color, int pattern);

int main(void)
{
   int gridArray[NUM_ROWS][NUM_COLS] =
                          { {0, 0, 0, 0, 0, 0},
                            {2, 4, 2, 4, 2, 4},
                            {1, 2, 3, 4, 5, 6},
                            {2, 3, 4, 15, 6, 7},
                            {5, 5, 5, 5, 5, 5}
                         };

   int width = CELL_SIZE * NUM_COLS;
   int height = CELL_SIZE * NUM_ROWS + 100;
   int row, column;   /* row, column of cell clicked */
   int color;               /* color of cell clicked */
   char message[100] = "Select a cell by clicking it";

   initwindow(width, height, "Grid");
   outtextxy(100, height - 50, message);

   drawGrid(gridArray);   /* Draw and color the grid */

   /* Get position and color of cell clicked */
   reportResult(&row, &column, &color);
   printf("You clicked the cell in row %d, column %d\n",
           (row + 1), (column + 1));

   /* Draw hatch pattern in cell clicked */
   recolor(row, column, color, HATCH_FILL);

   getch();
   closegraph();
}


/* Draw the grid corresponding to the color values in gridArray
 * Pre:    Array gridArray is defined
 * Post:   A two-dimensional grid is drawn with the same number
 *         rows and columns as gridArray. The cell at row r,
 *         column c has the color value of gridArray[r][c].
 */
void drawGrid(int gridArray[][NUM_COLS])
{
   int color;                           /* color of cell */
   int r, c;                /* row and column subscripts */
   /* Draw a grid cell for each array element */
   for (r = 0; r < NUM_ROWS; ++r) {
      for (c = 0; c < NUM_COLS; ++c) {
         /* Fill the cell */
         color = gridArray[r][c] % 16;    /* cell color */
         setfillstyle(SOLID_FILL, color);
         bar(c*CELL_SIZE, r*CELL_SIZE, /* top-left corner */
             c*CELL_SIZE + CELL_SIZE,     /* bottom-right */
             r*CELL_SIZE + CELL_SIZE);    /*    corner    */

         /* Draw cell border */
         setcolor(WHITE);                    /* border color */
         rectangle(c*CELL_SIZE, r*CELL_SIZE, /* top-left corner */
                   c*CELL_SIZE + CELL_SIZE,     /* bottom-right */
                   r*CELL_SIZE + CELL_SIZE);    /*    corner    */
      }
   }
}


/* Report the results of a mouse click by the user.
 * Pre:   The grid is displayed
 * Post:  The row, column, and color of the cell
 *        clicked are returned through row and column.
 */
void reportResult(int *row, int *column, int *color)
{
   int x, y;    /* (x, y) position of mouse click */

   clearmouseclick(WM_LBUTTONDOWN);
   while (!ismouseclick(WM_LBUTTONDOWN)) {
      delay(100);
   }
   getmouseclick(WM_LBUTTONDOWN, x, y);

   /* Convert x (y) pixel position to row (column) */
   *row = y / CELL_SIZE;
   *column = x / CELL_SIZE;
   *color = getpixel(x, y);     /* get pixel color */
}

/* Recolors a selected grid cell with a new color and pattern.
 * Pre:    The cell position, color,
 *         and pattern are defined.
 * Post:   The selected cell is filled with pattern
 */
void recolor(int r, int c, int color, int pattern)
{
   setfillstyle(pattern, color);
   bar(c*CELL_SIZE, r*CELL_SIZE,    /* top-left corner */
       c*CELL_SIZE + CELL_SIZE,        /* bottom-right */
       r*CELL_SIZE + CELL_SIZE);       /*    corner    */
}
