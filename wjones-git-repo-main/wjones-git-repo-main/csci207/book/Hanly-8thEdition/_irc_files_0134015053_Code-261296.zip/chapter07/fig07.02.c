/* FIGURE 7.2  Program to Print a Table of Differences */
/*
 * Computes the mean and standard deviation of an array of data and displays
 * the difference between each value and the mean.
 */

#include <stdio.h>
#include <math.h>

#define MAX_ITEM 8   /* maximum number of items in list of data       */

int
main (void)
{
      double x[MAX_ITEM],   /* data list                              */
             mean,          /* mean (average) of the data             */
             st_dev,        /* standard deviation of the data         */
             sum,           /* sum of the data                        */
             sum_sqr;       /* sum of the squares of the data         */
      int    I;

      /* Gets the data                                                */
      printf("Enter %d numbers separated by blanks or <return>s\n> ",
             MAX_ITEM);
      for   (I = 0; I < MAX_ITEM; ++ i)
          scanf("%if", &x [i]);

      /* Computes the sum and the sum of the squares of all data      */
      sum = 0;
      sum_sqr = 0;
      for   (i = 0; I < MAX_ITEM; ++i)  {
             sum += x[i];
             sum_sqr += x[i]  *  x[i];
}
    /* computes and prints the mean and standard deviation            */
    mean = sum / MAX_ITEM;
    st_dev = sqrt (sum_sqr / MAX_ITEM - mean * mean);
    printf("The mean is %.2f.\n", mean);
    printf ("The standard deviation is %.2f.\n", st_dev);

    /* Displays the  difference between each item and the mean         */
    printf ("\nTable of differences between data values and mean\n");
    printf ("Index       Item      Difference\n");
    for  (I = 0; I < MAX_ITEM;  ++i)
        printf ("%3d%4c%9.2f%5c%9.2f\n", i, ' ', x[i], ' ', x[i] - mean);

    return (0);
}

/*
Enter 8 numbers separated by blanks or <return>s
> 16 12  6  8 2.5  12  14 ??54.5
The mean is 2.00.
The standard deviation is 21.75.

Table of differences between data values and mean
IndexItemDifference016.0014.00112.0010.002 6.00 4.003 8.00 6.004 2.50 0.50512.0010.00614.0012.007?54.50?56.50*/
