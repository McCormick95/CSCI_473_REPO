/* Figure 7.24  Hospital Revenue Summary Main Function */
/*
 * Scans revenue figures for one year and stores them in a table organized
 * by unit and quarter. Displays the table and the annual totals for each
 * unit and the revenue totals for each quarter
 */

#include <stdio.h>

#define REVENUE_FILE "revenue.txt"    /* name of revenue data file    */
#define NUM_UNITS 5
#define NUM_QUARTERS 4

typedef enum
      {summer, fall, winter, spring}
quarter_t;

typedef enum
      {emerg, medic, oncol, ortho, psych}
unit_t;

int scan_table(double revenue[][NUM_QUARTERS], int num_rows);
void sum_rows(double row_sum[], double revenue[][NUM_QUARTERS], int num_rows);
void sum_columns(double col_sum[], double revenue[][NUM_QUARTERS], int num_rows);
void display_table(double revenue[][NUM_QUARTERS], const double unit_totals[],
                   const double quarter_totals[], int num_rows);
/* Insert function prototypes for any helper functions. */

int
main(void)
{
      double revenue[NUM_UNITS][NUM_QUARTERS]; /* table of revenue */
      double unit_totals[NUM_UNITS];           /* row totals */
      double quarter_totals[NUM_QUARTERS];     /* column totals */
      int    status;

status = scan_table(revenue, NUM_UNITS);
if (status == 1) {
      sum_rows(unit_totals, revenue, NUM_UNITS);
      sum_columns(quarter_totals, revenue, NUM_UNITS);
      display_table(revenue, unit_totals, quarter_totals,
                    NUM_UNITS);
   }
   return (0);
}
