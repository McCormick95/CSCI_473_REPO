/* Figure 7.26  Function display_table and Helper Functions display_quarter and whole_thousands */
/*
 * Displays the revenue table data (rounded to whole thousands) in table
 * form along with the row and column sums (also rounded).
 * Pre: revenue, unit_totals, quarter_totals, and num_rows are defined.
 * Post: Values stored in the three arrays are displayed rounded to
 * whole thousands.
 */
void
display_table(double       revenue[][NUM_QUARTERS], /* input */
              const double unit_totals[],           /* input */
              const double quarter_totals[],        /* input */
              int          num_rows)                /* input */
{
      unit_t unit;
      quarter_t quarter;

      /* Display heading */
      printf("%34cREVENUE SUMMARY\n%34c---------------\n\n", ' ', ' ');
      printf("%4s%11c", "Unit", ' ');
      for  (quarter = summer; quarter <= spring; ++quarter){
            display_quarter(quarter);
            printf("%8c", ' ');
      }
      printf("TOTAL*\n");
      printf("----------------------------------------");
      printf("----------------------------------------\n");

      /* Display table */
      for  (unit = emerg; unit <= psych; ++unit) {
            display_unit(unit);
          printf(" ");
          for (quarter = summer; quarter <= spring; ++quarter)
             printf("%14.2f", revenue[unit][quarter]);
          printf("%13d\n", whole_thousands(unit_totals[unit]));
      }
      printf("----------------------------------------");
      printf("----------------------------------------\n");
      printf("TOTALS*");
      for  (quarter = summer; quarter <= spring; ++quarter)
          printf("%14d", whole_thousands(quarter_totals[quarter]));
      printf("\n\n*in thousands of dollars\n");
}
/*
* Display an enumeration constant of type quarter_t
*/
void
display_quarter(quarter_t quarter)
{
      switch (quarter) {
      case summer: printf("Summer");
                   break;

      case fall:   printf("Fall ");
                   break;

      case winter: printf("Winter");
                   break;

      case spring: printf("Spring");
                   break;

      default:     printf("Invalid quarter %d", quarter);
      }
}

/*
 * Return how many thousands are in number
 */
int whole_thousands(double number)
{
    return (int)((number + 500)/1000.0);
}
